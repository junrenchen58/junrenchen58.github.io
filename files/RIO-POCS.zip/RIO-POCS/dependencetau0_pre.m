rng(16);
n = 500;
s = 5;
taulist = 0.04:0.08:0.84;
repe_phi = 50;
repe_x = 1;
times = 60;
m = times * s;
num_tau = length(taulist);

errlist = zeros(size(taulist));
for ii = 1:num_tau
    tau = taulist(ii);
    err_res = re_prenoise(n,s,times,tau,repe_phi,repe_x);
    errlist(ii) = mean(err_res);
end
subplot(121);
lineerr = plot(log(taulist),log(errlist),'LineWidth',1.5);
hold on;
theoerrlist = (log(errlist(1)) - 0.3 ) + 0.5*(log(taulist)-log(taulist(1)));
theoerrlist1 = (log(errlist(1)) - 0.3 ) +  (log(taulist)-log(taulist(1)));
linehalf = plot(log(taulist),theoerrlist,'--k');
line1 = plot(log(taulist),theoerrlist1,'-.k');
xlabel('$\log(\tau_0)$','Interpreter','latex')
ylabel('$\log(\|\mathbf{x}^\sharp-\mathbf{x}\|_2)$','Interpreter','latex')
legend([lineerr,linehalf,line1],{'esti. error','slope=$0.5$','slope=$1$'},'Interpreter','latex')
subplot(122)
plot([0,taulist],[0,errlist],'LineWidth',1.5); 
xlabel('$\tau_0$','Interpreter','latex')
ylabel('$\|\mathbf{x}^\sharp-\mathbf{x}\|_2$','Interpreter','latex')