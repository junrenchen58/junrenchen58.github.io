rng(14);
n = 500;
s = 5;
klist = [1,2,3,5,7,9,11,13];
num_k = length(klist);
repe_phi = 30;
repe_x = 1;
times = 60;
m = times * s;
zetalist = klist / m;
errlist = zeros(size(klist));
for ii = 1:num_k
    k = klist(ii);
    err_res = re_sparse_corruption(n,s,k,times,repe_phi, repe_x);
    errlist(ii) = mean(err_res);
end
subplot(121);
lineerr= plot(log(klist),log(errlist),'LineWidth',1.5);
hold on;
theoerrlist = (log(errlist(1)) + 0.25 ) + 0.5*(log(klist)-log(klist(1)));
theoerrlist1 = (log(errlist(1)) + 0.25 ) +  (log(klist)-log(klist(1)));
linehalf = plot(log(klist),theoerrlist,'--k');
line1 = plot(log(klist),theoerrlist1,'--k');
xlabel('$\log(\zeta_0 m)$','Interpreter','latex')
ylabel('$\log(\|\mathbf{x}^\sharp-\mathbf{x}\|_2)$','Interpreter','latex')
legend([lineerr,linehalf,line1],{'esti. error','slope=$0.5$','slope=$1$'},'Interpreter','latex')

subplot(122)
plot([0,zetalist],[0,errlist],'LineWidth',1.5); 
xlabel('$\zeta_0$','Interpreter','latex')
ylabel('$\|\mathbf{x}^\sharp-\mathbf{x}\|_2$','Interpreter','latex')
ylim([0,0.23]);