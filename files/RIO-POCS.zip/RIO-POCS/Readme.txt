Paper: Robust Instance Optimal Phase-Only Compressed Sensing
Authors: Junren Chen, Michael Ng, Jonathan Scarlett 
ArXiv: https://arxiv.org/abs/2408.06275
Date: July 10, 2025 


Figure 1 -- obtained by "dependencetau0_post"

Figure 2 -- obtained by "dependencetau0_pre"

Figure 3 -- obtained by "dependencezeta0"


**We thank Dr. Zhaoqiang Liu for his contributions of writing some codes**
**Contact chenjr58@connect.hku.hk for any issue of the codes** 