function err_res = re_sparse_corruption(n,s,k,times,repe_phi, repe_x)
m = ceil(times * s);
err_res = zeros(1,repe_phi);
for k_phi = 1:repe_phi
    Phi = randn(m,n) + randn(m,n) * j;
    err = 0;
    for k_x = 1:repe_x
        supp = datasample(1:n,s,'Replace',false);
        x = zeros(n,1);
        x(supp) = randn(s,1);
        x = x / norm(x);
        
        z = sign(Phi * x);
        if k >0
            absv = abs(Phi * x);
            [~,pos] = maxk(absv,k);
            z(pos) = z(pos) * j; %% this is the adversarial corruption we choose
        end

        kap = sqrt(pi/2); 
        A_z = [real(z'*Phi)/(kap*m);imag(diag(z)'*Phi)/sqrt(m)];
        herez = zeros(m+1,1);
        herez(1) = 1;
        x_star = kap * m * x / norm(Phi*x,1); 
        epsilon_pocs = norm(herez-A_z*x_star);
        zobtain = Basis_Pursuit(A_z, herez, epsilon_pocs);
        if norm(zobtain) < 1e-4
            err = max(err, 1.0);
        else
            err = max(err, norm(zobtain/norm(zobtain)-x));
        end
    end
    err_res(k_phi) = err;
end
end