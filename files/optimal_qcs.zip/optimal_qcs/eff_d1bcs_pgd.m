function [error,errl,x,xhat] = eff_d1bcs_pgd(n,m,act_k,k,eta,Lambda,T,mode)

% n - dimension; m - measurement number; act_k - actual l1 norm of signal
% k - estimated upper bound on act_k; eta - stepsize
% Lambda - dithering scale; T - iteration number
% mode - not important, just set as 2

%% D1bCS of effectively sparse vector

%% data generation
errl = zeros(1,T+1);
x = zeros(n,1); 
z = randi([1 ceil(act_k * 0.6)]); 

%% mode = 1 exact sparsity, 
if mode == 1
    z = k ; 
end

%% this looks crucial and the range of z should be small enough

a = (sqrt(act_k)+sqrt(act_k+(n*(n-act_k-z))/z))/n;
b = (sqrt(act_k)-z*a)/(n-z);
x(1:z) = a * sign(randn(z,1));
x(z+1:n) = b * sign(randn(n-z,1));

%%  bernoulli random matrix and uniform dither
A = rand(m,n);
B = A;
B(A<0.5)=1;
B(A>=0.5) = -1;
A = B;

tau = (rand(m,1)-0.5)*2*Lambda;
y = sign(A*x-tau);

%% for iteration 
xhat = zeros(n,1);

%% LOOP
for i = 1:T
    vec_m = sign(A*xhat-tau)-y;
    vec_m = vec_m .* A;
    grad = mean(vec_m)';
    xhat = xhat - eta * grad; 

    %% the additional truncation step
    xhat = l1proj(xhat,sqrt(k));
    
    if norm(xhat)>1
        xhat = xhat/norm(xhat);
    end
    
    errl(i+1) =  norm(xhat - x);
end
error = errl(T+1);
end

