function [error,errl,x,xhat] = d1bcs_pgd(n,m,act_k,k,eta,Lambda,T)

% n - dimension; m - measurement number; act_k - sparsity of signal
% k - estimated sparsity of signal; eta - stepsize
% Lambda - Dithering scale; T - iteration number

%% data generation
errl = zeros(1,T+1);
x = randn(n,1); 
xx = randsample(n,n-act_k);
x(xx) = 0; 
x = rand(1)*x/norm(x); %% x is in the unit ball

%%  bernoulli random matrix and uniform dither
A = rand(m,n);
B = A;
B(A<0.5)=1;
B(A>=0.5) = -1;
A = B;

tau = (rand(m,1)-0.5)*2*Lambda;
y = sign(A*x-tau);

%% for iteration 
xhatt = zeros(n,1);
xhat = zeros(n,1);

%% LOOP
for i = 1:T
    vec_m = sign(A*xhat-tau)-y;
    vec_m = vec_m .* A;
    grad = mean(vec_m)';
    xhat = xhat - eta * grad; 

    %% the truncation step
    [~,suppx] = maxk(abs(xhat),k);
    xhatt(suppx) = xhat(suppx); 
    xhat = xhatt;
    xhatt = zeros(n,1);

    %% additional projection step
    if norm(xhat)>1
        xhat = xhat/norm(xhat);
    end
    errl(i+1) =  norm(xhat - x);
end
error = errl(T+1);
end

