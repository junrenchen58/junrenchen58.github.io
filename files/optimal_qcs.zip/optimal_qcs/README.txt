MATLAB Codes for "Optimal Quantized Compressed Sensing via Projected Gradient Descent" 

Authors: Junren Chen and Ming Yuan 
Arxiv: https://arxiv.org/abs/2407.04951

Codes shared by Junren Chen (https://junrenchen58.github.io/) on 03/17/2025

# Recovery of sparse vectors

onebcs_pgd.m : 1bCS of sparse vector
d1bcs_pgd.m : D1bCS of sparse vector
dmbcs_pgd.m : DMbCS of sparse vector

# Recovery of low-rank matrices

lr1bcs_pgd.m : 1bCS of low-rank matrix
lrd1bcs_pgd.m : D1bCS of low-rank matrix 
lrdmbcs_pgd.m : DMbCS of low-rank matrix

# Recovery of effectively sparse vectors

eff_onebcs_pgd.m : 1bCS of effectively sparse vector
eff_d1bcs_pgd.m : D1bCS of effectively sparse vector
eff_dmbcs_pgd.m : DMbCS of effectively sparse vector

# Auxiliary files

l1proj.m : Projection onto scaled l1 ball
