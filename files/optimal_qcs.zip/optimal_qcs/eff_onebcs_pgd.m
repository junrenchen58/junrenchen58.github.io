function [error,errl,x,xhat] = eff_onebcs_pgd(n,m,act_k,k,eta,T)

% n - dimension; m - measurement number; act_k - actual l-1 norm of signal
% k - estimated upper bound on act_k
% eta - stepsize; T - iteration number

%% 1bCS of effectively sparse vectors
%% data generation

errl = zeros(1,T+1);
x = zeros(n,1); 
z = randi([1 ceil(act_k * 0.6)]); 

%% this looks crucial and the range of z should be small enough

a = (sqrt(act_k)+sqrt(act_k+(n*(n-act_k-z))/z))/n;
b = (sqrt(act_k)-z*a)/(n-z);
x(1:z) = a * sign(randn(z,1));
x(z+1:n) = b * sign(randn(n-z,1));

%% note that the above l1 norm would be slightly smaller than sqrt(act_k)

A = randn(m,n);
y = sign(A*x);

%% for initialization 

xhatt = randn(n,1);
xhatt = xhatt / norm(xhatt);
xhat = xhatt;

%% LOOP
for i = 1:T
    vec_m = sign(A*xhat)-y;
    vec_m = vec_m .* A;
    grad = mean(vec_m)';
    xhat = xhat - eta * grad; 
    
    %% the additional truncation step
    xhat = l1proj(xhat,sqrt(k));

    %% normalization
    xhat = xhat / norm(xhat); 
    errl(i+1) =  norm(xhat - x);
end

error = errl(T+1);

end

