function [error,errl,x,xhat] = eff_dmbcs_pgd(n,m,act_k,k,eta,L,delta,T)

% n - dimension; m - measurement number; act_k - actual l1 norm of signal
% k - estimated upper bound on act_k; eta - stepsize
% L - number of quantization levels/values
% delta - quantization resolution; T - iteration number

%% DMbCS of effectively sparse vector

%% data generation
errl = zeros(1,T+1);
x = zeros(n,1); 
z = randi([1 ceil(act_k * 0.6)]);  

%% This looks crucial and the range of z should be small enough
a = (sqrt(act_k)+sqrt(act_k+(n*(n-act_k-z))/z))/n;
b = (sqrt(act_k)-z*a)/(n-z);
x(1:z) = a * sign(randn(z,1));
x(z+1:n) = b * sign(randn(n-z,1));

%%  bernoulli random matrix and uniform dither
A = rand(m,n);
B = A;
B(A<0.5)=1;
B(A>=0.5) = -1;
A = B;

tau = (rand(m,1)-0.5)*delta;
y = A*x-tau;
y1 = delta*(floor(y/delta)+0.5);
y1(y>=(L*delta/2)) = (L-1)*delta/2;
y1(y<=(-L*delta/2)) = (1-L)*delta/2;
y = y1;

%% for iteration 
xhat = zeros(n,1);

%% LOOP
for i = 1:T
    yn = A*xhat-tau;
    yn1 = delta*(floor(yn/delta)+0.5);
    yn1(yn>=(L*delta/2)) = (L-1)*delta/2;
    yn1(yn<=(-L*delta/2)) = (1-L)*delta/2;
    yn = yn1;
    %% calculating the measurements in xhat
    vec_m = yn-y;
    vec_m = vec_m .* A;
    grad = mean(vec_m)';
    xhat = xhat - eta * grad; 

    %% the additional truncation step
    xhat = l1proj(xhat,sqrt(k));
    
    if norm(xhat)>1
        xhat = xhat/norm(xhat);
    end
    errl(i+1) =  norm(xhat - x);
end
error = errl(T+1);
end

