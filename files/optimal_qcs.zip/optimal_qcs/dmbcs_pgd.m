function [error,errl,x,xhat] = dmbcs_pgd(n,m,act_k,k,eta,L,delta,T)

% n - dimension; m - measurement number; act_k - sparsity of signal
% k - estimated sparsity of signal; eta - stepsize; 
% L - number of quantization levels/values
% delta - quantizer resolution; T - iteration number

%%DMbCS of sparse vector

%% data generation
errl = zeros(1,T+1);
x = randn(n,1); 
xx = randsample(n,n-act_k);
x(xx) = 0; 
x = rand(1)*x/norm(x); %% x is in the unit ball

%%  bernoulli random matrix and uniform dither
A = rand(m,n);
B = A;
B(A<0.5)=1;
B(A>=0.5) = -1;
A = B;

tau = (rand(m,1)-0.5)*delta;
y = A*x-tau;
y1 = delta*(floor(y/delta)+0.5);
y1(y>=(L*delta/2)) = (L-1)*delta/2;
y1(y<=(-L*delta/2)) = (1-L)*delta/2;
y = y1;

%% for iteration 
xhatt = zeros(n,1);
xhat = zeros(n,1);

%% LOOP
for i = 1:T
    yn = A*xhat-tau;
    yn1 = delta*(floor(yn/delta)+0.5);
    yn1(yn>=(L*delta/2)) = (L-1)*delta/2;
    yn1(yn<=(-L*delta/2)) = (1-L)*delta/2;
    yn = yn1;
    %% calculating the gradient in xhat
    vec_m = yn-y;
    vec_m = vec_m .* A;
    grad = mean(vec_m)';
    xhat = xhat - eta * grad; 
    %% the truncation step
    [~,suppx] = maxk(abs(xhat),k);
    xhatt(suppx) = xhat(suppx); 
    xhat = xhatt;
    xhatt = zeros(n,1);
    %% additional projection step
    if norm(xhat)>1
        xhat = xhat/norm(xhat);
    end
    errl(i+1) =  norm(xhat - x);
end
error = errl(T+1);
end

