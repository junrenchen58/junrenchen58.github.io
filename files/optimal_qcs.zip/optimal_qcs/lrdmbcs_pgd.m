function [error,errl,x,xhat] = lrdmbcs_pgd(n,m,act_k,k,eta,L,delta,T)

% n - sqrt(n)*sqrt(n) matrix; m - measurement number
% act_k - actual rank of matrix; k - estimated rank of matrix
% eta - stepsize; L - number of quantization levels/values
% delta - quantization resolution; T - iteration number

%% DMbCS of low-rank matrix

%% data generation
errl = zeros(1,T+1);
n1 = sqrt(n);
x = randn(n1,n1);
[U,S,V] = svd(x);
Ur = U(:,1:act_k);
Sr = S(1:act_k,1:act_k);
Vr = V(:,1:act_k);
x = Ur*Sr*Vr';
x = x/norm(x,'fro'); %% live in standard sphere for 1bCS
x = reshape(x,[n,1]); %% vectorization in R^n
x = rand(1)*x/norm(x); %% x is in the unit ball

%%  bernoulli random matrix and uniform dither
A = rand(m,n);
B = A;
B(A<0.5)=1;
B(A>=0.5) = -1;
A = B;

tau = (rand(m,1)-0.5)*delta;
y = A*x-tau;
y1 = delta*(floor(y/delta)+0.5);
y1(y>=(L*delta/2)) = (L-1)*delta/2;
y1(y<=(-L*delta/2)) = (1-L)*delta/2;
y = y1;

%% for iteration 
xhat = zeros(n,1);

%% LOOP
for i = 1:T
    yn = A*xhat-tau;
    yn1 = delta*(floor(yn/delta)+0.5);
    yn1(yn>=(L*delta/2)) = (L-1)*delta/2;
    yn1(yn<=(-L*delta/2)) = (1-L)*delta/2;
    yn = yn1;
    %% calculating the measurements in xhat
    vec_m = yn-y;
    vec_m = vec_m .* A;
    grad = mean(vec_m)';
    xhat = xhat - eta * grad; 

    %% the projection step
    xmat = reshape(xhat,[n1,n1]);
    [U,S,V] = svd(xmat);
    Ur = U(:,1:k);
    Sr = S(1:k,1:k);
    Vr = V(:,1:k);
    xmat = Ur*Sr*Vr';
    xhat = reshape(xmat,[n,1]);
    
    %% additional projection
    if norm(xhat)>1
        xhat = xhat / norm(xhat);
    end

    errl(i+1) =  norm(xhat - x);
end
error = errl(T+1);
end

