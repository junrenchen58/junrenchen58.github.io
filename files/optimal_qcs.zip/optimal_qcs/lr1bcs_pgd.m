function [error,errl,x,xhat] = lr1bcs_pgd(n,m,act_k,k,eta,T)

% n - sqrt(n) * sqrt(n) matrix; m - measurement number;
% act_k - actual rank of matrix; k - our estimate of matrix rank;
% eta - stepsize; T - iteration number

%% 1bCS of low-rank matrix

%% data generation
errl = zeros(1,T+1);
n1 = sqrt(n);
x = randn(n1,n1);
[U,S,V] = svd(x);
Ur = U(:,1:act_k);
Sr = S(1:act_k,1:act_k);
Vr = V(:,1:act_k);
x = Ur*Sr*Vr';
x = x/norm(x,'fro'); %% live in standard sphere for 1bCS
x = reshape(x,[n,1]); %% vectorization in R^n
A = randn(m,n);
y = sign(A*x);

%% for initialization 
xhatt = randn(n,1);
xhat = xhatt;
xhat = xhat / norm(xhat,'fro');

%% LOOP
for i = 1:T
    vec_m = (sign(A*xhat)-y);
    vec_m = vec_m .* A;
    grad = mean(vec_m)';
    xhat = xhat - eta * grad; 
    
    %% the projection step
    xmat = reshape(xhat,[n1,n1]);
    [U,S,V] = svd(xmat);
    Ur = U(:,1:k);
    Sr = S(1:k,1:k);
    Vr = V(:,1:k);
    xmat = Ur*Sr*Vr';
    xhat = reshape(xmat,[n,1]);
    
    %% normalization
    xhat = xhat / norm(xhat); 
    errl(i+1) =  norm(xhat - x);
end
error = errl(T+1);
end

