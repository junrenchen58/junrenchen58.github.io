function r = zed(~) %#ok<STOUT>
% Extracts the Z component of a quaternion.

% Copyright © 2005 Stephen J. Sangwine and Nicolas Le Bihan.
% See the file : Copyright.m for further details.

error('Obsolete private function zed called.')

end

% $Id: zed.m 1113 2021-02-01 18:41:09Z sangwine $
