function [err,Relerrs_QTAF] = FQTAF_Gaussian1D(d,m,iter,gamma,eta,npower_iter)

%% Make signal and data (var -> noise level)
Amatrix = 0.5* (randn(m,d) +randn(m,d)*qi+randn(m,d)*qj+randn(m,d)*qk);
x = randn(d,1) + randn(d,1) * qi + randn(d,1) * qj + randn(d,1) * qk;
x = x / norm(x);
var     = 0.0;
noise   = var * randn(m, 1);
y       = abs(Amatrix  * x).^2 + noise;


%% run QTAF algorithm
[Relerrs_QTAF,~] = QTAF1D(y, x, d,m,eta,gamma,npower_iter,iter, Amatrix); %iNULL_tr_test
err = Relerrs_QTAF(iter);

end

