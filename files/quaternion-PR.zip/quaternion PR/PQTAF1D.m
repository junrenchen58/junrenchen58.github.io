function [Relerrs,z] = PQTAF1D(y,x,d,m,eta,gamma,npower_iter,iter,inneriter,Amatrix)

%% Initialization
z0 = randn(d,1) + randn(d,1) * qi +  randn(d,1) * qj +  randn(d,1) * qk; 
z0 = z0 / norm(z0);    % Initial guess
normest = sqrt(sum(y(:)) / numel(y(:)));    % Estimate norm to scale eigenvector

Arnorm  = sqrt(sum(abs(Amatrix).^2, 2)); % norm of rows of Amatrix
ymag    = sqrt(y);
ynorm   = ymag ./ (Arnorm .* normest);

%% finding the angle of inner product

Anorm = Amatrix ./ Arnorm;
[ysort, ~] = sort(ynorm, 'ascend');
ythresh    = ysort(round(m / (6/5))); % 6/5 the orthogonality-promoting initialization parameter
ind        = (abs(ynorm) >= ythresh);

for tt = 1:npower_iter                   % Truncated power iterations
    z0 = Anorm' * (ind .* (Anorm * z0));
    z0 = z0 /norm(z0);
end

zz          = normest * z0;                   % Apply scaling
Relerrs = norm(x - zz*sign(zz' * x) ) / norm(x); % Initial rel. error

%% PQTAF update
outiter = floor(iter / inneriter);
for tt = 1:outiter
    for kk = 1:inneriter
        
        Az    = Amatrix * zz; %A(z);
        ratio = abs(Az) ./ ymag;
        yz    = ratio > 1 / (1 +  gamma);
        grad = (1/(2*m)) * Amatrix' * (Az .* yz .* (1 - ymag./abs(Az)));
        zz = zz - eta * grad;

    end
    realform = [zz.w,zz.x,zz.y,zz.z];
    XX = realform.' * realform;
    [U,~,~] = svd(XX);XX = U(:,4);
    zz = zz * (XX(1) - XX(2) * qi - XX(3) * qj - XX(4) * qk);
    % estimate the right quaternion factor via SVD
    zz = zz.v;
    % Removing the real part
    if norm(zz + x)<norm(zz - x)
        zz = -1 * zz;
    end
    % adjusting the sign (+1 / -1)
    Relerrs = [Relerrs; norm(zz-x)];
end
z = zz;
end


