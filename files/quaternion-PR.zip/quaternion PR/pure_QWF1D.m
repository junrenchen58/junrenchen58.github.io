function [Relerrs,zz] = pure_QWF1D(y, x, d,m,eta,npower_iter,iter,inneriter,Amatrix)

%% PQWF based on observed data
% iter: overall number of iterations
% inneriter: Tp in the paper

%% Initialization
z0 = randn(d,1) + randn(d,1) * qi +  randn(d,1) * qj +  randn(d,1) * qk; 
z0 = z0 / norm(z0);    % Initial guess
normest = sqrt(sum(y(:)) / numel(y(:)));    
% Estimate norm to scale eigenvector

for tt = 1:npower_iter    % power iteration
    z0 = Amatrix' * (y .* (Amatrix * z0));
    z0 = z0 / norm(z0);
end

zz       = normest * z0;                   % Apply scaling
realform = [zz.w,zz.x,zz.y,zz.z];
XX = realform.' * realform;
[U,~,~] = svd(XX);
XX = U(:,4);
zz = zz * (XX(1) - XX(2) * qi - XX(3) * qj - XX(4) * qk);
% estimate the right quaternion factor via SVD
zz = zz.v; % Removing the real part
if norm(zz + x)<norm(zz - x)
    zz = -1 * zz;
end
% adjusting the sign (+1 / -1)
Relerrs = [norm(zz-x)];


%% pure_WF update
outiter = floor(iter / inneriter);

for tt = 1:outiter
    for kk = 1:inneriter       
        Az = Amatrix * zz;
        Lam = abs(Az).^2 - y; 
        grad = (1/m) * Amatrix' * (Lam .* Az);
        zz = zz - eta * grad;
    end
    realform = [zz.w,zz.x,zz.y,zz.z];
    XX = realform.' * realform;
    [U,~,~] = svd(XX);XX = U(:,4);
    zz = zz * (XX(1) - XX(2) * qi - XX(3) * qj - XX(4) * qk);
    
    % estimate the right quaternion factor via SVD
    zz = zz.v;

    % Removing the real part
    if norm(zz + x)<norm(zz - x)
        zz = -1 * zz;
    end

    % adjusting the sign (+1 / -1)
    Relerrs = [Relerrs; norm(zz-x)];

end

