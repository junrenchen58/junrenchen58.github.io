function [err,errlist] = FQWF_Gaussian1D(d,m,iter,eta,npower_iter)

%% This simulates QWF for vector
% d - dimension; m - measurement number; iter - number of iteration
% eta - stepsize; npower_iter - number of iteration for spectral initialize

%% Make signal and data (var --> noise level)
Amatrix = 0.5* (randn(m,d) +randn(m,d)*qi+randn(m,d)*qj+randn(m,d)*qk);
x = randn(d,1) + randn(d,1) * qi + randn(d,1) * qj + randn(d,1) * qk;
x = x / norm(x);
var     = 0.0;
noise   = var * randn(m, 1);
y       = abs(Amatrix  * x).^2 + noise;


%% Run QWF algorithm
[errlist,~] = QWF1D(y, x, d,m,eta,npower_iter,iter,Amatrix); 
err = errlist(end);

end

