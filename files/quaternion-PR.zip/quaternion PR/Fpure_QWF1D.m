function [err,errlist] = Fpure_QWF1D(d,m,iter,inneriter,eta,npower_iter)

%% end-to-end implementation of PQWF (Algorithm 3)

%% Make signal and data (var -> noise level)
Amatrix = 0.5* (randn(m,d) +randn(m,d)*qi+randn(m,d)*qj+randn(m,d)*qk);
x =  randn(d,1) * qi + randn(d,1) * qj + randn(d,1) * qk;
x = x / norm(x);
var     = 0.0;
noise   = var * randn(m, 1);
y       = abs(Amatrix  * x).^2 + noise;


%% run pure_QWF algorithm
 
[errlist ,~] = pure_QWF1D(y, x, d,m,eta,...
    npower_iter,iter,inneriter,Amatrix); 

err = errlist(end);

end

