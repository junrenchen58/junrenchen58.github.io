function grad = Qcompute_grad(z,y,m,theta_lb,theta_ub,theta_h,A,At)

%% Compute the gradient in QTWF

yz = A(z); 
Kt = 1/m* norm(abs(yz(:)).^2 - y(:), 1); 

Eub = abs(yz) / norm(z)   <= theta_ub;
Elb = abs(yz) / norm(z)   >= theta_lb;
Eh  =  abs(y - abs(yz).^2) <= theta_h * Kt / norm(z) * abs(yz);

grad = 1/(2*m) * At(  ( abs(yz).^2-y ) ./ (abs(yz).^2) .*yz ...
                          .* Eub .* Elb .* Eh );   
end

