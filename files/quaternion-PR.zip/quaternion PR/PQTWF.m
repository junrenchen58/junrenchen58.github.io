function [err,Relerrs] = PQTWF(y,x,d,m,theta_lb,theta_ub,theta_h,theta_y,iter,inneriter,eta,npower_iter,A,At)

%% PQTWF based on observations 

%% Initialization
z0 = randn(d,1) + randn(d,1) * qi +  randn(d,1) * qj +  randn(d,1) * qk; 
z0 = z0 / norm(z0);    % Initial guess
normest = sqrt(sum(y(:)) / numel(y(:)));    % Estimate norm to scale eigenvector

for tt = 1:npower_iter  % Truncated power iteration
    ytr = y.* (abs(y) <=  theta_y^2 * normest^2 );
    z0 = At( ytr.* (A(z0)) ); z0 = z0/norm(z0 );
end
zz          = normest * z0;                   % Apply scaling
Relerrs = norm(x - zz*sign(zz' * x) ) / norm(x); % Initial rel. error

%% QTWF update
outiter = floor(iter / inneriter);
for tt = 1:outiter
    for kk = 1:inneriter
        
        grad = Qcompute_grad(zz,y,m,theta_lb,theta_ub,theta_h, A,At);
        zz = zz - eta * grad;

    end
    realform = [zz.w,zz.x,zz.y,zz.z];
    XX = realform.' * realform;
    [U,~,~] = svd(XX);XX = U(:,4);
    zz = zz * (XX(1) - XX(2) * qi - XX(3) * qj - XX(4) * qk);
    % estimate the right quaternion factor via SVD
    zz = zz.v;
    % Removing the real part
    if norm(zz + x)<norm(zz - x)
        zz = -1 * zz;
    end
    % adjusting the sign (+1 / -1)
    Relerrs = [Relerrs; norm(zz-x)];
end
err = Relerrs(end);
