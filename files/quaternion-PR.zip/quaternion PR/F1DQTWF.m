function [err,errlist] = F1DQTWF(d,m,theta_lb,theta_ub,theta_h,theta_y,iter,eta,npower_iter)

%% End-to-end simulation of QTWF

%% Make signal and data (var -> noise level)
Amatrix = 0.5* (randn(m,d) +randn(m,d)*qi+randn(m,d)*qj+randn(m,d)*qk);
x = randn(d,1) + randn(d,1) * qi + randn(d,1) * qj + randn(d,1) * qk;
x = x / norm(x);
var     = 0.0;
noise   = var * randn(m, 1);
y       = abs(Amatrix  * x).^2 + noise;
A  = @(I) Amatrix  * I;
At = @(Y) Amatrix' * Y;

%% Call function
[err, errlist] = QTWF(y,x,d,m,theta_lb,theta_ub,theta_h,theta_y,iter,eta,npower_iter,A,At);

end

