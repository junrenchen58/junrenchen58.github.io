function Sigmaest = newnonada_C(X,C)

%% Our new 2-bit non-adaptive estimator tilde{Sigma}_{2b}
%% Based on triangular dithering

% X : sample matrix whose i-th row is i-th sample
% C : A tuning parameter in dithering scale

n = size(X,1);
d = size(X,2);

% dithering
Lambda = C*sqrt(log(n)); 
Dither1 = (rand(n,d)-1/2)*Lambda;
Dither2 = (rand(n,d)-1/2)*Lambda;

% quantization
X = X +Dither1 + Dither2;
X(X>2*Lambda) = 3*Lambda/2;
X(X<-2*Lambda) = -3*Lambda/2;
X = Lambda * (floor(X/Lambda)+1/2);

% estimation
Sigmaest = X' * X /n - Lambda^2/4 * eye(d);

end

