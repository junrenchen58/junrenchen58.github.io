function Sigmaest = nonada_C(X,C)

%% The estimator hat{Sigma}_{na} from 22 AOS by Dirksen, Maly and Rauhut
% X: n * d matrix whose i-th role is the i-th sample
% C: A tuning parameter in Lambda

n = size(X,1);
d = size(X,2);

% dithering scale
Lambda = C* sqrt(log (n));

% dither
Dither1 = (2*rand(n,d)-1)*Lambda;
Dither2 = (2*rand(n,d)-1)*Lambda;

% quantized samples
dotX_1 = sign(X + Dither1);
dotX_2 = sign(X + Dither2);

% estimation
Sigmaest = 0.5*Lambda^2 * (dotX_1' * dotX_2 + dotX_2' * dotX_1) /n;
end

