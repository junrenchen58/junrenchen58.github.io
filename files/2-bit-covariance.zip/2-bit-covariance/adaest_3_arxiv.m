function Sigmaest = adaest_3_arxiv(X,C)

%% The estimator hat{Sigma}_a from "Tuning-free one-bit covariance estimation using data-driven dithering"
% X: sample matrix whose i-th row is the i-th sample Xi
% C: A tuning parameter depending on K

n = size(X,1);
d = size(X,2);
X1_q = zeros(n-1,d);
X2_q = zeros(n-1,d);
Lambda = max(abs(X(1,:)));
for i = 1:n-1
    C1 = C*sqrt(log(i)); % C is a tuning parameter
    cur_sam = X(i+1,:);
    dither1 = (2*rand(1,d)-1) * C1 * Lambda;
    dither2 = (2*rand(1,d)-1) * C1 * Lambda;
    X1_q(i,:) = C1*Lambda * sign(cur_sam + C1*Lambda *dither1);
    X2_q(i,:) = C1*Lambda * sign(cur_sam + C1*Lambda *dither2);
    Lambda = (i*Lambda + max(abs(X(i+1,:))))/(i+1);
end
Sigmaest = (X1_q'*X2_q+X2_q'*X1_q)/(2*(n-1));
end

