function Sigmaest = adaest_C(X,C)

%% Our estimator tilde{Sigma}(s) which is parameter-free and dimension-free
% X : sample matrix; 
% C : parameter s in Remark 1 -- C = 1 returns our main estimator

n = size(X,1);
d = size(X,2);
Lambda = max(abs(X)); % dithering scale varying across coordinates
Lambda = C*Lambda; % C shrinks the dithering scales

% dithering
Dither1 = (rand(n,d)-1/2)*diag(Lambda);
Dither2 = (rand(n,d)-1/2)*diag(Lambda);
Dither = Dither1 + Dither2;
X_q = zeros(n,d);

for i = 1:d
    % quantization
    A = Lambda(i)*(floor((X(:,i) + Dither(:,i))/Lambda(i))+1/2);
    A(A>1.5*Lambda(i)) = 1.5*Lambda(i);
    A(A<-1.5*Lambda(i)) = -1.5*Lambda(i); % quantization
    X_q(:,i) = A;
end

% estimation
Sigmaest = X_q'*X_q/n - diag(Lambda.^2)/4;
end

