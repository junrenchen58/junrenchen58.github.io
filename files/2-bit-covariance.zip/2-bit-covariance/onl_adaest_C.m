function Sigmaest = onl_adaest_C(X,C,C1)

%% Our online estimator tilde{Sigma}_{on}
% X : sample matrix; C : tuning parameter in Lambda
% C1 : tuning parameter in n0

n = size(X,1);
d = size(X,2);

%% using the first n0 samples to set dithering scale in an online setting
n0 = ceil(C1 * log(n));
X0 = X(1:n0,:);
Lambda = mean(X0.^2);
Lambda = C * sqrt(Lambda * log(n));

%% start quantizing subsequent samples
X_to_q = X(n0+1:end,:); %% only the later n-n1 samples need to be quantized
Dither1 = (rand(n-n0,d)-1/2)*diag(Lambda);
Dither2 = (rand(n-n0,d)-1/2)*diag(Lambda);
Dither = Dither1 + Dither2;
X_q = zeros(n-n0,d);
for i = 1:d
    A = Lambda(i)*(floor((X_to_q(:,i) + Dither(:,i))/Lambda(i))+1/2);
    A(A>1.5*Lambda(i)) = 1.5*Lambda(i);
    A(A<-1.5*Lambda(i)) = -1.5*Lambda(i);
    X_q(:,i) = A;
end

%% estimation
X_q = [X0;X_q];
Sigmaest = X_q'*X_q/n - (1-n0/n)*diag(Lambda.^2)/4;

end

