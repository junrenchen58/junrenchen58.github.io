MATLAB Codes For "A Parameter-Free Two-Bit Covariance Estimator
with Improved Operator Norm Error Rate"

ArXiv: https://arxiv.org/pdf/2308.16059v2
Authors: Junren Chen and Michael K. Ng
Date: 03/18/2025

Code shared by Junren Chen (https://junrenchen58.github.io/)


# Existing estimators:

------------
(a) nonada_C.m - hat{Sigma}_{na}. 

See "Covariance estimation under one-bit quantization"
See Eq. (1.2) in the paper

------------
(b) adaest_3_arxiv.m - hat{Sigma}_a. 

See "Tuning-free one-bit covariance estimation using data-driven dithering"


# Our estimators:

------------
(c) newnonada_C.m - tilde{Sigma}_{2b}. 

Our new 2-bit nonadaptive estimator, based on triangular dithering. 
See Eq. (2.10) in the paper

------------
(d) adaest_C.m - tilde{Sigma}(s). 

Our main estimator. 
See Eq. (3.3) in the paper.
See also Remark 1 for an extension. 
Parameter C in the code <---> s in Remark 1

------------
(e) onl_adaest_C.m - tilde{Sigma}_{on}.

An adaptation of our main estimator to the online setting
See Eq. (5.3) in the paper.



