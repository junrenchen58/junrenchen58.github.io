MATLAB Codes for "One-Bit Phase Retrieval: Optimal Rates and Efficient Algorithms"

Authors: Junren Chen & Ming Yuan 
Arxiv: https://arxiv.org/pdf/2405.04733

Codes shared by Junren Chen on 03/23/2025
Please contact Junren Chen at chenjr58@connect.hku.hk for any problems


*********************************
# Low-dimensional case: Figure 2 (left)

figure2left.m                        : generate Figure 2 (left)
onebitlinear.m & onebitlinear_repe.m : solve 1-bit linear system by linear programing
GD_albe.m      & GD_albe_repe.m      : solve 1-bit phase retrieval by our Algorithms 1 and 3


*********************************
# High-dimensional sparse case: Figure 2 (right)

figure2right.m                       : generate Figure 2 (right)
onebcs_pgd.m   & onebcs_pgd_repe.m   : solve 1-bit compressed sensing by NBIHT
SPGD_albe.m    & SPGD_albe_repe.m    : solve 1-bit sparse phase retrieval by our Algorithms 2 and 4


*********************************
# Natural images: Figure 4

OnebPR_StanfordQuad.m : test Algorithms 2 and 4 over the real image of StanfordQuad


*********************************
# Figure 3 - it can be easily simulated by the above 1b(S)PR codes











